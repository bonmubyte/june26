from rest_framework import viewsets
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from rest_framework.decorators import action, api_view
from django.db.models import Q
from .models import Article, Category, Journalist, Keyword
from .serializers import ArticleSerializer, CategorySerializer, JournalistSerializer, KeywordSerializer

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class JournalistViewSet(viewsets.ModelViewSet):
    queryset = Journalist.objects.all()
    serializer_class = JournalistSerializer

class KeywordViewSet(viewsets.ModelViewSet):
    queryset = Keyword.objects.all()
    serializer_class = KeywordSerializer

class ArticleViewSet(viewsets.ModelViewSet):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer

    def get_queryset(self):
        queryset = Article.objects.all()
        category = self.request.query_params.get('category', None)
        if category:
            queryset = queryset.filter(category__name__iexact=category)
        return queryset

    @action(detail=False, methods=['get'])
    def search(self, request):
        query = request.query_params.get('search', None)
        if query:
            queryset = self.get_queryset().filter(
                Q(title__icontains=query) |
                Q(subtitle__icontains(query)) |
                Q(journalist__name__icontains(query)) |
                Q(content__icontains(query))
            )
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return Response([])

    @action(detail=False, methods=['get'])
    def by_keyword(self, request):
        keyword = request.query_params.get('keyword', None)
        if keyword:
            queryset = self.get_queryset().filter(keywords__name__iexact=keyword)
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return Response([])

    @action(detail=False, methods=['get'])
    def by_journalist(self, request):
        journalist = request.query_params.get('journalist', None)
        if journalist:
            queryset = self.get_queryset().filter(journalist__name__iexact=journalist)
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return Response([])

@api_view(['GET'])
def article_detail(request, category, url):
    category_obj = get_object_or_404(Category, name__iexact=category)
    article = get_object_or_404(Article, category=category_obj, url=url)
    serializer = ArticleSerializer(article)
    return Response(serializer.data)
